import cam1 from '../assets/images/cam1.png'
import cam2 from '../assets/images/cam2.png'
import cam3 from '../assets/images/cam3.png'

export const product = [
    {
        id: 1,
        img: cam1,
        model: 'PowerShot SX620 HS',
        brand: 'Canon',
        weekday: 630 ,
        holiday: 750,
        week: 4380,
        month: 12250
    },
    {
        id: 2,
        img: cam2,
        model: 'PowerShot SX620 HS',
        brand: 'Canon',
        weekday: 630 ,
        holiday: 750,
        week: 4380,
        month: 12250
    },
    {
        id: 3,
        img: cam3,
        model: 'PowerShot SX620 HS',
        brand: 'Canon',
        weekday: 630 ,
        holiday: 750,
        week: 4380,
        month: 12250
    }
]