import cam1 from '../assets/images/cam1.png'
import cam2 from '../assets/images/cam2.png'
import cam3 from '../assets/images/cam3.png'
import cam4 from '../assets/images/cam4.png'
import cam5 from '../assets/images/cam5.png'
import cam6 from '../assets/images/cam6.png'



export const data = [
    {
        img: cam1,
        id: 1,
        model: 'PowerShot SX620 HS',
        brand: 'Canon',
        weekday: 630 ,
        holiday: 750,
        week: 4380,
        month: 12250
    },
    {
        img: cam2,
        id: 2,
        model: 'PowerShot SX620 HS',
        brand: 'Canon',
        weekday: 630 ,
        holiday: 750,
        week: 4380,
        month: 12250
    },
    {
        img: cam3,
        id: 3,
        model: 'PowerShot SX620 HS',
        brand: 'Canon',
        weekday: 630 ,
        holiday: 750,
        week: 4380,
        month: 12250
    },
    {
        img: cam4,
        id: 4,
        model: 'PowerShot SX620 HS',
        brand: 'Canon',
        weekday: 630 ,
        holiday: 750,
        week: 4380,
        month: 12250
    },
    {
        img: cam5,
        id: 5,
        model: 'PowerShot SX620 HS',
        brand: 'Canon',
        weekday: 630 ,
        holiday: 750,
        week: 4380,
        month: 12250
    },
    {
        img: cam6,
        id: 6,
        model: 'PowerShot SX620 HS',
        brand: 'Canon',
        weekday: 630 ,
        holiday: 750,
        week: 4380,
        month: 12250
    },
]
